1.A3_Q2_baseline_and_first_model.ipybn has baseline model and the model 
I change from the baseline
2.Inception4_simple_ver_0.67_0.97.ipynb has my simplified inception-4 model
3.MobileNetV3_0.97_0.41.ipynb has MobileNetV3 model and is my best one 
4.Sorry I made a mistake in Q2_report that I use the MobileNetV3-large model instead 
of MobileNetV3-small model,because I couldn't find a way to modify my PDF :(
5.For in A3_Q1 there are lots of training steps and make the report so long,I recommend
to see the jupyter notebook.